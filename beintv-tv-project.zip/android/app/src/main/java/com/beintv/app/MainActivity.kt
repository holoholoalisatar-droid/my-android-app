package com.beintv.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.ui.PlayerView

/**
 * البنية:
 *  - PlayerView (ExoPlayer) في الخلفية: يستخدم MediaCodec الخاص بالنظام مباشرة،
 *    فيتجاوز قيد دعم HEVC في محرك Chromium/WebView.
 *  - WebView شفاف فوقه: يعرض واجهة index.html (القوائم، التصميم، التنقل بالريموت)
 *    ويتواصل مع ExoPlayer عبر جسر JavaScript (WebAppInterface).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.playerView)
        webView = findViewById(R.id.webView)

        setupPlayer()
        setupWebView()
    }

    private fun setupPlayer() {
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        playerView.useController = false // التحكم يتم بالكامل من واجهة HTML

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> notifyJs("buffering", "جاري التحميل")
                    Player.STATE_READY -> if (player.playWhenReady) notifyJs("playing", "مباشر")
                    Player.STATE_ENDED -> notifyJs("ended", "انتهى البث")
                    Player.STATE_IDLE -> {}
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                notifyJs("error", "تعذر تشغيل البث (${error.errorCodeName})")
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.setBackgroundColor(Color.TRANSPARENT)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(WebAppInterface(this), "TVPlayer")
        webView.loadUrl("file:///android_asset/index.html")
    }

    /** يُستدعى من WebAppInterface عند اختيار قناة في واجهة HTML */
    fun playChannel(url: String) {
        runOnUiThread {
            notifyJs("loading", "جارٍ الاتصال…")
            val dataSourceFactory = DefaultHttpDataSource.Factory()
                .setUserAgent("BeinTV-Android/1.0")
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(15000)
            val mediaSource = HlsMediaSource.Factory(dataSourceFactory)
                .createMediaSource(MediaItem.fromUri(url))
            player.setMediaSource(mediaSource)
            player.prepare()
            player.playWhenReady = true
        }
    }

    fun stopChannel() {
        runOnUiThread { player.stop() }
    }

    private fun notifyJs(state: String, message: String) {
        runOnUiThread {
            val safeMessage = message.replace("'", "\\'")
            val js = "if(window.onPlayerState){onPlayerState('$state','$safeMessage')}"
            webView.evaluateJavascript(js, null)
        }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
