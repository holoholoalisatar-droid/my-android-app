package com.beintv.app

import android.webkit.JavascriptInterface

/**
 * يُحقن داخل الـ WebView باسم "TVPlayer" — انظر MainActivity.setupWebView().
 * الدوال هنا هي بالضبط ما تستدعيه واجهة index.html (window.TVPlayer.xxx).
 */
class WebAppInterface(private val activity: MainActivity) {

    @JavascriptInterface
    fun playChannel(url: String, name: String) {
        activity.playChannel(url)
    }

    @JavascriptInterface
    fun stop() {
        activity.stopChannel()
    }

    @JavascriptInterface
    fun exitApp() {
        activity.finish()
    }
}
