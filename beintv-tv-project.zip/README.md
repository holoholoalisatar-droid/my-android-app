# BEIN TV — تطبيق أندرويد (WebView + ExoPlayer)

## الفكرة
- طبقة الفيديو: **ExoPlayer** (مكتبة Media3 الرسمية من Google) يشغّل روابط HLS مباشرة عبر
  `MediaCodec` الخاص بنظام أندرويد — نفس الطريقة التي يستخدمها VLC تمامًا، فيتجاوز قيد
  دعم HEVC الموجود في محرك Chromium/WebView.
- طبقة الواجهة: **WebView شفاف** فوق الفيديو يعرض `index.html` (نفس التصميم، القوائم،
  التنقل بالريموت) بدون أي تعديل في شكلها.
- الربط بينهما: **جسر JavaScript** (`WebAppInterface`) — عند اختيار قناة في HTML، يُستدعى
  `window.TVPlayer.playChannel(url, name)` فيبدأ ExoPlayer التشغيل فعليًا، ويُعاد إرسال
  حالة التشغيل (تحميل/مباشر/خطأ) إلى الواجهة عبر `window.onPlayerState(state, message)`.

## هيكل المشروع
```
android/
  build.gradle                 (مستوى المشروع)
  settings.gradle
  app/
    build.gradle                (اعتماديات Media3/ExoPlayer)
    src/main/
      AndroidManifest.xml       (يدعم Android TV Leanback Launcher)
      assets/index.html         (الواجهة — نسخة من web/index.html)
      java/com/beintv/app/
        MainActivity.kt
        WebAppInterface.kt
      res/
        layout/activity_main.xml
        values/strings.xml
        values/styles.xml
        drawable/tv_banner.xml  (بانر مؤقت — استبدله بصورة حقيقية)
web/
  index.html                    (نفس الواجهة، صالحة للمعاينة مباشرة بأي متصفح)
```

## خطوات التشغيل

### 1) معاينة سريعة للواجهة (اختياري)
افتح `web/index.html` مباشرة في أي متصفح — تعمل بوضع معاينة (`hls.js`) لتجربة
التصميم والتنقل، لكن بدون حل مشكلة HEVC (لأنها لسه داخل متصفح).

### 2) بناء تطبيق أندرويد فعلي
1. افتح **Android Studio** → New Project → **Empty Views Activity** (Kotlin)،
   اسم الحزمة `com.beintv.app` (يجب أن يطابق `namespace` في `app/build.gradle`).
2. استبدل الملفات التي أنشأها المشروع الجديد بملفات مجلد `android/` هنا (نفس المسارات).
3. تأكد أن `index.html` موجود داخل `app/src/main/assets/`.
4. اعمل Sync لملفات Gradle (سيقوم Android Studio تلقائيًا بإنشاء `gradle-wrapper` والملفات
   المفقودة عند فتح المشروع لأول مرة إن احتجت).
5. شغّل التطبيق على **جهاز Android TV حقيقي أو محاكي Android TV** (الأفضل)، أو أي هاتف/تابلت
   للتجربة الأولية.

### 3) استبدال البانر
`drawable/tv_banner.xml` هو بانر مؤقت. استبدله بصورة `tv_banner.png` (320×180) حقيقية
لعرض احترافي في واجهة أندرويد تيفي الرئيسية.

## بناء APK بدون تثبيت أي برنامج (موصى به) — عبر GitHub Actions

هذه أسهل طريقة لتحصل على ملف APK حقيقي بدون كمبيوتر قوي أو تنصيب Android Studio.
الملف `.github/workflows/build-apk.yml` مُجهّز مسبقًا داخل هذا المشروع.

### الخطوات (كلها من المتصفح، حتى من الموبايل):
1. أنشئ حساب مجاني على **github.com** إذا ما عندك واحد.
2. أنشئ مستودع (Repository) جديد — اجعله **Public** أو **Private** (كلاهما يعمل مع Actions مجانًا لحساب شخصي).
3. ارفع **كل محتويات** هذا المجلد (بما فيها `.github/` و`android/` و`web/`) إلى جذر المستودع مباشرة
   — إما بالسحب والإفلات عبر واجهة GitHub (Add file → Upload files)، أو عبر `git push` إذا تعرف تستخدمه.
4. بعد الرفع، اذهب لتبويب **Actions** أعلى صفحة المستودع — ستجد "Build APK" يعمل تلقائيًا (يأخذ ٣-٥ دقائق).
5. بعد اكتمال البناء (علامة ✓ خضراء)، افتح ذلك التشغيل (run)، وفي الأسفل قسم **Artifacts**
   ستجد ملف `beintv-debug-apk` — حمّله (يأتي كملف zip يحتوي على `app-debug.apk` بداخله).
6. انسخ `app-debug.apk` لهاتفك وثبّته (فعّل "السماح بتثبيت من مصادر غير معروفة" إذا طلب أندرويد ذلك).

**ملاحظة**: هذا يبني نسخة Debug (للتجربة) — تعمل تمامًا وتُثبّت بشكل طبيعي، لكنها غير موقّعة لرفعها
على متجر Google Play. لو احتجت لاحقًا نسخة Release موقّعة للنشر، أخبرني وأجهّز لك خطوة التوقيع.

- **الحد الأدنى لإصدار أندرويد**: 21 (يغطي عمليًا كل أجهزة Android TV الحالية).
- **لماذا هذا يحل مشكلة HEVC فعليًا**: ExoPlayer لا يمر عبر قيود ترخيص HEVC في متصفح Chrome/WebView؛
  هو يطلب من نظام أندرويد نفسه (`MediaCodec`) فك التشفير، وهذا متاح على أي جهاز يدعم HEVC بالهاردوير
  (أغلب أجهزة أندرويد الحديثة، بما فيها هاتفك كما أثبت الفحص السابق).
- لو ظهر خطأ تشغيل رغم ذلك لقناة معيّنة، الرسالة ستظهر بوضوح في شريط الحالة السفلي
  (`onPlayerState('error', ...)`) مع سبب الخطأ الفعلي من ExoPlayer — بلا تخمين هذه المرة.
- **الخروج بزر الرجوع**: حاليًا `WebAppInterface.exitApp()` جاهزة، يمكنك ربطها بزر
  "رجوع" في `index.html` عبر `window.TVPlayer.exitApp()` إذا أردت سلوك خروج مخصص
  بدل السلوك الافتراضي لأندرويد.
